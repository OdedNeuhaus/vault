# Admin policy - replaces day-to-day use of the root token.
# Broad on purpose; split into narrower policies as your team grows.
path "*" {
  capabilities = ["create", "read", "update", "patch", "delete", "list", "sudo"]
}
