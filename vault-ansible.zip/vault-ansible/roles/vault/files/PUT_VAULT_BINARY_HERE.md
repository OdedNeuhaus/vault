Place the Vault binary here as `roles/vault/files/vault` (gitignored),
or point `vault_binary_src` at wherever it lives on the controller.
If the binary is already on the target VM, set `vault_binary_remote_src: true`
and `vault_binary_src` to its path there.
