# Vault on-prem - Ansible

Deploys HashiCorp Vault 2.1.2 CE on Ubuntu: Integrated Storage (Raft), TLS, systemd,
file audit log, Prometheus metrics, automatic init/unseal, baseline config via the API.
One node or a 3-node HA cluster, decided only by how many hosts are in `vault_servers`.

```
site.yml                    provision_vm.yml -> vault.yml
provision_vm.yml            >>> PLACEHOLDER for your VM creation + base infra <<<
vault.yml                   applies roles/vault to group vault_servers
inventories/onprem/
  hosts.yml                 nodes (ansible_host, vault_fqdn)
  group_vars/vault_servers/
    main.yml                site settings
    secrets.yml.example     -> secrets.yml (ansible-vault encrypted)
roles/vault/
  defaults/main.yml         every tunable, documented
  tasks/                    preflight > os > install > tls > config > service > init_unseal > configure
  templates/                vault.hcl, systemd unit, openssl cnf, logrotate, profile
  files/policies/*.hcl      ACL policies (file name = policy name)
  files/vault               <- the Vault binary (gitignored)
artifacts/<cluster>/        generated on the controller: CA + node certs, init.json (gitignored)
```

## First run

```bash
cp /path/to/vault roles/vault/files/vault
cp inventories/onprem/group_vars/vault_servers/secrets.yml.example \
   inventories/onprem/group_vars/vault_servers/secrets.yml
$EDITOR inventories/onprem/group_vars/vault_servers/secrets.yml   # admin password
ansible-vault encrypt inventories/onprem/group_vars/vault_servers/secrets.yml
$EDITOR inventories/onprem/hosts.yml                              # IPs + FQDNs

ansible-playbook site.yml --ask-vault-pass
```

What the first run does: installs everything, creates a cluster CA and node certs,
initializes Vault (5 keys, threshold 3), saves keys + root token to
`artifacts/<cluster>/init.json`, unseals all nodes (followers join the leader),
enables the audit log / KV v2 at `secret/` / userpass, writes the policies, creates
`admin`, verifies the admin login, and revokes the root token.

**Then, immediately:**
1. Distribute the 5 unseal keys to 5 custodians.
2. Decide on unsealing after restarts:
   - **Automated:** put 3+ keys into `secrets.yml` as `vault_unseal_keys`.
     Convenient, but anyone with the ansible-vault password can unseal.
   - **Manual:** leave it empty. Any run that finds Vault sealed stops with a clear message.
3. Delete `init.json` (or `ansible-vault encrypt` it). Its root token is already revoked.

## Day 2

| Task | Command |
|---|---|
| Re-apply everything (idempotent) | `ansible-playbook vault.yml --ask-vault-pass` |
| Policies only | add/edit `roles/vault/files/policies/*.hcl`, then `--tags vault_configure` |
| Upgrade | replace the binary, set `vault_version`, run `vault.yml` (`serial: 1`: each node restarts and is unsealed before the next) |
| Renew certs | delete `artifacts/<cluster>/tls/<host>.crt`, run `--tags vault_tls` (reloads, no restart) |
| Add HA nodes | add hosts to `vault_servers`, run `vault.yml` |
| Corporate CA | `vault_tls_mode: provided` + `vault_tls_cert_src/key_src/ca_src` |

Tags: `vault_preflight`, `vault_os`, `vault_install`, `vault_tls`, `vault_config`,
`vault_service`, `vault_init`, `vault_configure`.

## Things to know

- **Restarts seal Vault.** A change to `vault.hcl`, the unit file or the binary triggers a
  restart. Without `vault_unseal_keys` the run then stops at the unseal step until you
  unseal by hand.
- **Root token** is revoked after the first run. Vault 2.0+ requires an authenticated token
  for `sys/generate-root`, so use the admin token if you ever need a new root token.
- **PGP-encrypted keys:** set `vault_pgp_keys` (one per share) and the first run initializes
  only; custodians decrypt and unseal by hand, then re-run for the baseline config.
- **No collections needed:** only `ansible.builtin` (fits air-gapped controllers).
  The controller needs `openssl` when `vault_tls_mode: selfsigned`.
- **Backups (next step):** schedule `vault operator raft snapshot save` with a token that has
  `read` on `sys/storage/raft/snapshot`.
