# HashiCorp Vault on Ubuntu (on-prem, air-gapped)

Single-node Vault **2.1.2 Community Edition**, Integrated Storage (Raft), TLS, systemd,
file audit log, Prometheus metrics. Ready to grow to a 3-node HA cluster.

Analogy: Vault is a bank vault. **Init** builds the vault and cuts 5 keys; **unseal**
needs any 3 keys turned at once after every restart; the **root token** is the master
key you lock away once day-to-day staff (admin user + policies) exist.

## Layout

```
vars.env                       <- the ONLY file you edit (FQDN, IP, version)
templates/vault.hcl.tpl        -> /etc/vault.d/vault.hcl
templates/vault-openssl.cnf.tpl   (cert SANs: FQDN, IP, localhost, 127.0.0.1)
templates/vault-profile.sh.tpl -> /etc/profile.d/vault.sh  (VAULT_ADDR)
files/vault.service            -> /etc/systemd/system/vault.service
files/vault.env                -> /etc/vault.d/vault.env
files/vault-logrotate          -> /etc/logrotate.d/vault
policies/*.hcl                    Vault ACL policies (name = file name)
scripts/00..04                    the steps below, idempotent
```

On the VM:

| Path | Purpose | Owner / mode |
|---|---|---|
| /usr/local/bin/vault | binary | root 0755 |
| /etc/vault.d/ | config + TLS | root:vault 0750 |
| /opt/vault/data | Raft data | vault 0750 |
| /var/log/vault/audit.log | audit log | vault 0640 |

## Prerequisites

- Ubuntu 22.04/24.04 VM, 2+ vCPU, 4+ GB RAM, SSD disk for /opt/vault
- A DNS record for `VAULT_FQDN` (or /etc/hosts on clients)
- Ports 8200/tcp (API/UI) and 8201/tcp (cluster) open

## Step 0 - Edit vars.env

Set `VAULT_FQDN`, `VAULT_IP`, `VAULT_NODE_ID`.

## Step 1 - Get the binary (connected machine)

```bash
./scripts/00-fetch-on-connected-host.sh
```
Downloads the zip, verifies HashiCorp's GPG signature + SHA256, extracts `artifacts/vault`.
Copy the whole bundle (with `artifacts/`) to the VM, e.g. `/root/vault-deploy`.
If you have Nexus/Artifactory, upload `artifacts/vault` there instead.

## Step 2 - Install (VM, root)

```bash
sudo ./scripts/01-install.sh
```
Creates the `vault` user and dirs, installs the binary, renders all config, installs the
systemd unit + logrotate, disables swap, opens ufw ports (only if ufw is active).

## Step 3 - TLS (VM, root)

```bash
sudo ./scripts/02-tls.sh
```
- **Corporate CA (preferred):** put `vault.crt`, `vault.key`, `ca.crt` in `./tls/` first.
- **No CA:** leave `./tls/` empty -> a local CA + cert are generated. Move
  `/root/vault-ca.key` off the box. Distribute `/etc/vault.d/tls/ca.crt` to clients.

## Step 4 - Start + initialize (VM, root)

```bash
sudo ./scripts/03-start-and-init.sh
```
Writes `/root/vault-init.json` (5 unseal keys + root token). Distribute the keys to
5 different people/places, then `shred -u /root/vault-init.json`.

## Step 5 - Unseal (needed after EVERY restart)

```bash
vault operator unseal   # run 3 times, a different key each time
vault status            # Sealed: false
```

## Step 6 - Baseline configuration

```bash
export VAULT_TOKEN=<root token>
./scripts/04-configure.sh
vault login -method=userpass username=admin
vault token revoke <root token>
```
Enables the file audit device, KV v2 at `secret/`, userpass auth, applies every
`policies/*.hcl`, creates user `admin`. Re-run any time you add a policy file.

## Step 7 - Verify

```bash
curl -s https://$VAULT_FQDN:8200/v1/sys/health | python3 -m json.tool
vault kv put secret/apps/test hello=world && vault kv get secret/apps/test
tail -1 /var/log/vault/audit.log
curl -s "https://$VAULT_FQDN:8200/v1/sys/metrics?format=prometheus" | head
```
UI: `https://<VAULT_FQDN>:8200/ui`

## Operations cheat sheet

| Task | Command |
|---|---|
| Status | `vault status` |
| Logs | `journalctl -u vault -f` |
| Reload config/TLS | `systemctl reload vault` |
| Backup (Raft snapshot) | `vault operator raft snapshot save /backup/vault-$(date +%F).snap` |
| Restore | `vault operator raft snapshot restore <file>` |
| Upgrade | bump `VAULT_VERSION`, re-run 00 + 01, `systemctl restart vault`, unseal |

Put the snapshot command in a systemd timer with a dedicated token that only has
`read` on `sys/storage/raft/snapshot`.

## Moving this into Ansible

| Bundle piece | Ansible |
|---|---|
| vars.env | `group_vars/vault.yml` |
| `*.tpl` (`${VAR}`) | `templates/*.j2` (`{{ var }}`) + `template` module |
| files/* | `copy` module |
| user / dirs | `user`, `file` modules |
| binary | `get_url` from your artifact repo + `checksum:` |
| swap / fstab | `command: swapoff -a` + `mount state=absent` / `replace` |
| systemd | `systemd` module (`daemon_reload`, `enabled`) + handler for `reload` |
| 02-tls.sh | `community.crypto.openssl_privatekey` / `openssl_csr` / `x509_certificate` |
| 03 init / unseal | **keep manual** - a one-time ceremony; don't put keys in the playbook |
| 04-configure.sh | `ansible.builtin.uri` against the Vault API, or better: Terraform `vault` provider |

## Notes

- **Auto-unseal** removes the manual unseal step, but on-prem it needs an HSM (Enterprise)
  or a second "transit" Vault. Shamir keys are the standard choice for a first deployment.
- **HA:** add 2 more VMs with unique `VAULT_NODE_ID`, uncomment `retry_join` blocks,
  and include all node names in each cert's SANs.
- **Kubernetes:** next step is usually the `kubernetes` auth method per cluster +
  External Secrets Operator or Vault Secrets Operator in each cluster.
- **License:** Vault CE is under the Business Source License; internal use is permitted.
