#!/usr/bin/env bash
# Run on the Vault VM as root. Idempotent: safe to re-run.
# Installs the binary, creates the user/dirs, lays down all config files.
source "$(dirname "$0")/lib.sh"
require_root
cd "$BUNDLE_DIR" || exit 1

log "Verifying binary"
[[ -f artifacts/vault ]] || { echo "artifacts/vault missing - run 00-fetch on a connected host first" >&2; exit 1; }
(cd artifacts && sha256sum -c vault.sha256)

log "Creating vault system user"
id vault &>/dev/null || useradd --system --home-dir /etc/vault.d --no-create-home --shell /usr/sbin/nologin vault

log "Creating directories"
install -d -o root  -g vault -m 0750 /etc/vault.d
install -d -o root  -g vault -m 0750 /etc/vault.d/tls
install -d -o vault -g vault -m 0750 /opt/vault /opt/vault/data
install -d -o vault -g vault -m 0750 /var/log/vault

log "Installing binary"
install -o root -g root -m 0755 artifacts/vault /usr/local/bin/vault
vault version

log "Rendering config files"
render templates/vault.hcl.tpl        /etc/vault.d/vault.hcl  root:vault 0640
render templates/vault-profile.sh.tpl /etc/profile.d/vault.sh root:root  0644
install -o root -g vault -m 0640 files/vault.env       /etc/vault.d/vault.env
install -o root -g root  -m 0644 files/vault.service   /etc/systemd/system/vault.service
install -o root -g root  -m 0644 files/vault-logrotate /etc/logrotate.d/vault

log "Disabling swap (mlock is off, so secrets must never page to disk)"
swapoff -a
sed -ri '/^[^#].*\sswap\s/s/^/# disabled-for-vault: /' /etc/fstab

log "Firewall"
if command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow 8200/tcp comment 'Vault API/UI'
  ufw allow 8201/tcp comment 'Vault cluster (Raft)'
else
  echo "ufw not active - open 8200/tcp (API/UI) and 8201/tcp (cluster) in your firewall."
fi

systemctl daemon-reload
systemctl enable vault
log "Install complete. Next: scripts/02-tls.sh"
