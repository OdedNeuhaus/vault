#!/usr/bin/env bash
# Run on a machine WITH internet access. Downloads + verifies the Vault binary,
# then you carry ./artifacts/vault into the air-gapped network (or your artifact repo).
# Needs: curl, gpg, unzip, sha256sum
set -euo pipefail
cd "$(dirname "$0")/.."
source ./vars.env

BASE="https://releases.hashicorp.com/vault/${VAULT_VERSION}"
ZIP="vault_${VAULT_VERSION}_linux_${VAULT_ARCH}.zip"
SUMS="vault_${VAULT_VERSION}_SHA256SUMS"

mkdir -p artifacts && cd artifacts

echo "==> Downloading Vault ${VAULT_VERSION} (${VAULT_ARCH})"
curl -fsSLO "${BASE}/${ZIP}"
curl -fsSLO "${BASE}/${SUMS}"
curl -fsSLO "${BASE}/${SUMS}.sig"

echo "==> Verifying HashiCorp GPG signature"
curl -fsSL https://www.hashicorp.com/.well-known/pgp-key.txt | gpg --import 2>/dev/null
gpg --verify "${SUMS}.sig" "${SUMS}"

echo "==> Verifying checksum"
sha256sum --ignore-missing -c "${SUMS}"

unzip -o "${ZIP}" vault
chmod 0755 vault
sha256sum vault > vault.sha256
./vault version
echo "==> Done. Transfer artifacts/vault and artifacts/vault.sha256 into the bundle on the VM."
