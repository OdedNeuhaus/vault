#!/usr/bin/env bash
# Run on the Vault VM as root. Starts Vault and initializes it ONCE.
# Initialization creates the unseal keys + root token -- this is a one-time ceremony,
# deliberately NOT automated in Ansible beyond this point.
source "$(dirname "$0")/lib.sh"
require_root
export VAULT_ADDR="https://127.0.0.1:8200"

log "Starting vault"
systemctl start vault
for _ in $(seq 1 30); do
  curl -s -o /dev/null "${VAULT_ADDR}/v1/sys/health" && break
  sleep 1
done

# vault status exits 2 when sealed, so capture output instead of piping
STATUS="$(vault status -format=json 2>/dev/null || true)"
if grep -q '"initialized": true' <<<"$STATUS"; then
  log "Vault already initialized - nothing to do."
  vault status || true
  exit 0
fi

OUT=/root/vault-init.json
log "Initializing (5 key shares, threshold 3)"
# Hardened alternative: add  -pgp-keys="alice.asc,bob.asc,..." -root-token-pgp-key="admin.asc"
# so each custodian receives an unseal key encrypted to their own PGP key.
( umask 077; vault operator init -key-shares=5 -key-threshold=3 -format=json > "$OUT" )

cat <<EOF

!! ${OUT} contains the 5 unseal keys and the root token.
!! 1. Hand each key to a different custodian (password manager / sealed envelope).
!! 2. Store the root token securely; you will revoke it after 04-configure.sh.
!! 3. Then:  shred -u ${OUT}

Next: unseal by running this 3 times, pasting a different key each time:
    vault operator unseal
EOF
