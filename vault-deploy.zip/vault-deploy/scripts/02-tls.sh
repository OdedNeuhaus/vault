#!/usr/bin/env bash
# Run on the Vault VM as root.
#
# Option A (preferred) - corporate CA:
#   Put vault.crt (server cert, or cert+intermediates chain), vault.key and ca.crt
#   into ./tls/ in this bundle before running. They are installed as-is.
#   Generate the CSR with:  openssl req -new -newkey rsa:4096 -nodes \
#       -keyout tls/vault.key -out tls/vault.csr -config <rendered vault-openssl.cnf>
#
# Option B - no corporate CA: if ./tls/ is empty, a local CA + server cert are generated.
source "$(dirname "$0")/lib.sh"
require_root
cd "$BUNDLE_DIR" || exit 1
TLS=/etc/vault.d/tls

if [[ -f tls/vault.crt && -f tls/vault.key && -f tls/ca.crt ]]; then
  log "Installing certificates from ./tls (corporate CA)"
  install -o root -g vault -m 0644 tls/vault.crt "$TLS/vault.crt"
  install -o root -g vault -m 0640 tls/vault.key "$TLS/vault.key"
  install -o root -g vault -m 0644 tls/ca.crt    "$TLS/ca.crt"
elif [[ -f "$TLS/vault.crt" ]]; then
  log "Certificate already present in $TLS - leaving it alone"
else
  log "Generating local CA + server certificate"
  WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
  render templates/vault-openssl.cnf.tpl "$WORK/openssl.cnf" root:root 0600

  openssl req -x509 -newkey rsa:4096 -sha256 -days 3650 -nodes \
    -keyout "$WORK/ca.key" -out "$WORK/ca.crt" -subj "/CN=${VAULT_CLUSTER_NAME} Local CA"

  openssl req -new -newkey rsa:4096 -nodes \
    -keyout "$WORK/vault.key" -out "$WORK/vault.csr" -config "$WORK/openssl.cnf"

  openssl x509 -req -in "$WORK/vault.csr" -CA "$WORK/ca.crt" -CAkey "$WORK/ca.key" \
    -CAcreateserial -out "$WORK/vault.crt" -days 825 -sha256 \
    -extfile "$WORK/openssl.cnf" -extensions v3_req

  install -o root -g vault -m 0644 "$WORK/vault.crt" "$TLS/vault.crt"
  install -o root -g vault -m 0640 "$WORK/vault.key" "$TLS/vault.key"
  install -o root -g vault -m 0644 "$WORK/ca.crt"    "$TLS/ca.crt"
  # CA private key goes to root's home - MOVE IT OFF THE BOX after setup.
  install -o root -g root  -m 0600 "$WORK/ca.key"    /root/vault-ca.key
  echo "!! /root/vault-ca.key is the CA private key. Move it to offline storage, then delete it here."
fi

log "Trusting the CA system-wide (so the vault CLI and curl work without flags)"
install -o root -g root -m 0644 "$TLS/ca.crt" /usr/local/share/ca-certificates/vault-ca.crt
update-ca-certificates >/dev/null

openssl x509 -in "$TLS/vault.crt" -noout -subject -ext subjectAltName -enddate
log "TLS done. Next: scripts/03-start-and-init.sh"
