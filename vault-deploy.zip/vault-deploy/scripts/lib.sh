#!/usr/bin/env bash
# Shared helpers. Sourced by the other scripts.
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=../vars.env
set -a; source "${BUNDLE_DIR}/vars.env"; set +a

require_root() { [[ $EUID -eq 0 ]] || { echo "Run as root (sudo)." >&2; exit 1; }; }

# render <template> <dest> <owner:group> <mode>
# Substitutes ${VAR} from vars.env (python3 ships with Ubuntu; no extra packages).
# Ansible equivalent: the `template` module.
render() {
  local src="$1" dst="$2" owner="$3" mode="$4" tmp
  tmp="$(mktemp)"
  python3 -c 'import os,string,sys; print(string.Template(open(sys.argv[1]).read()).substitute(os.environ), end="")' "$src" > "$tmp"
  install -o "${owner%%:*}" -g "${owner##*:}" -m "$mode" "$tmp" "$dst"
  rm -f "$tmp"
}

log() { echo -e "\n==> $*"; }
