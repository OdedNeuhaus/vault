#!/usr/bin/env bash
# Run after Vault is unsealed. Idempotent: safe to re-run whenever policies change.
# Requires a privileged token:  export VAULT_TOKEN=<root token>   (first run)
#                               vault login -method=userpass username=admin (later runs)
source "$(dirname "$0")/lib.sh"
cd "$BUNDLE_DIR" || exit 1
export VAULT_ADDR="${VAULT_ADDR:-https://127.0.0.1:8200}"

vault token lookup >/dev/null || { echo "Not authenticated - set VAULT_TOKEN first." >&2; exit 1; }

# Each check captures CLI output first (piping into grep -q can SIGPIPE under pipefail)
log "Audit device (file)"
AUDITS="$(vault audit list -format=json 2>/dev/null || true)"
if ! grep -q '"file/"' <<<"$AUDITS"; then
  vault audit enable file file_path=/var/log/vault/audit.log
fi

log "KV v2 secrets engine at secret/"
ENGINES="$(vault secrets list -format=json)"
if ! grep -q '"secret/"' <<<"$ENGINES"; then
  vault secrets enable -path=secret -version=2 kv
fi

log "Userpass auth method"
AUTHS="$(vault auth list -format=json)"
if ! grep -q '"userpass/"' <<<"$AUTHS"; then
  vault auth enable userpass
fi

log "Policies (every policies/*.hcl, name = file name)"
for f in policies/*.hcl; do
  vault policy write "$(basename "$f" .hcl)" "$f"
done

log "Admin user"
if ! vault read -format=json auth/userpass/users/admin >/dev/null 2>&1; then
  read -rsp "Choose a password for Vault user 'admin': " ADMIN_PW; echo
  vault write auth/userpass/users/admin password="$ADMIN_PW" token_policies=admin token_ttl=8h token_max_ttl=24h
  unset ADMIN_PW
else
  echo "admin exists (policies re-applied above)."
fi

cat <<'EOF'

Done. Verify the admin login works, then revoke the root token:
    vault login -method=userpass username=admin
    vault token revoke <ROOT_TOKEN>
(If you ever need root again:  vault operator generate-root  with 3 unseal keys.)
EOF
