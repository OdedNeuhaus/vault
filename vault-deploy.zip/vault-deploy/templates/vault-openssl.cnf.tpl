# OpenSSL request config for the Vault server certificate.
# Use it to generate a CSR for your corporate CA, or with 02-tls.sh for a local CA.
[req]
default_bits       = 4096
prompt             = no
distinguished_name = dn
req_extensions     = v3_req

[dn]
CN = ${VAULT_FQDN}

[v3_req]
basicConstraints = CA:FALSE
keyUsage         = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth, clientAuth
subjectAltName   = @alt_names

[alt_names]
DNS.1 = ${VAULT_FQDN}
DNS.2 = localhost
IP.1  = ${VAULT_IP}
IP.2  = 127.0.0.1
