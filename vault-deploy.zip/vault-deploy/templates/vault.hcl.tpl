# /etc/vault.d/vault.hcl  -- rendered from templates/vault.hcl.tpl
ui            = true
cluster_name  = "${VAULT_CLUSTER_NAME}"

# Recommended with Integrated Storage (Raft). Swap is disabled by 01-install.sh instead.
disable_mlock = true

api_addr     = "https://${VAULT_FQDN}:8200"
cluster_addr = "https://${VAULT_FQDN}:8201"

storage "raft" {
  path    = "/opt/vault/data"
  node_id = "${VAULT_NODE_ID}"

  # Growing to a 3-node HA cluster later? Add one block per peer:
  # retry_join {
  #   leader_api_addr     = "https://vault-2.corp.internal:8200"
  #   leader_ca_cert_file = "/etc/vault.d/tls/ca.crt"
  # }
}

listener "tcp" {
  address         = "0.0.0.0:8200"
  cluster_address = "0.0.0.0:8201"
  tls_cert_file   = "/etc/vault.d/tls/vault.crt"
  tls_key_file    = "/etc/vault.d/tls/vault.key"
  tls_min_version = "tls12"

  # Lets Prometheus scrape /v1/sys/metrics?format=prometheus without a token.
  # Metrics contain no secrets; set to false if you prefer token-based scraping.
  telemetry {
    unauthenticated_metrics_access = true
  }
}

telemetry {
  prometheus_retention_time = "30s"
  disable_hostname          = true
}
