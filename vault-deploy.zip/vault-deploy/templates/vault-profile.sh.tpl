# /etc/profile.d/vault.sh -- CLI defaults for every shell on this VM
export VAULT_ADDR="https://${VAULT_FQDN}:8200"
