# Example app policy: read-only access to secrets under secret/apps/*
path "secret/data/apps/*" {
  capabilities = ["read"]
}

path "secret/metadata/apps/*" {
  capabilities = ["read", "list"]
}
